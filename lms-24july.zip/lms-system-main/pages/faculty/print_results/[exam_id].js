import React from "react";
import { useRouter } from "next/router";
import PrintResultContainer from "@/components/G2OfficerDashboard/PrintResultContainer";

const PrintExamResult = () => {
  return (
    <div>
      <PrintResultContainer />
    </div>
  );
};

export default PrintExamResult;
