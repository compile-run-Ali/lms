import React from 'react'

export default function ForgetPassword() {
    return (
        <div>
            superAdminPassword@123
        </div>
    )
}

